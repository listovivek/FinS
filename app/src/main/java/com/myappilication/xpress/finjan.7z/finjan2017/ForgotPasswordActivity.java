package com.myappilication.xpress.finjan2017;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.myappilication.xpress.finjan2017.models.login.forget.forgotreq;
import com.myappilication.xpress.finjan2017.models.login.forget.forgotresp;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;
import com.myappilication.xpress.finjan2017.webservice.RxClient;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by sureshmano on 3/29/2017.
 */

public class ForgotPasswordActivity  extends AppCompatActivity{
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    EditText et_forgot_email;
    Button btn_forgot_password;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgotpass);
        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();

        et_forgot_email = (EditText) findViewById(R.id.et_forgot_email);
        btn_forgot_password = (Button) findViewById(R.id.bt_forget);

        context = getApplicationContext();



        et_forgot_email.setText("muthu.k@quadrupleindia.com");

        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.commit();

        btn_forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mtd_forget_password();
            }


        });




    }

    private void mtd_forget_password() {

        RxClient.get(context).ForgetPass(new forgotreq(et_forgot_email.getText().toString()), new Callback<forgotresp>() {
            @Override
            public void success(forgotresp forgotresp, Response response) {

                if (forgotresp.getStatus().equals("200")){
                    Toast.makeText(context, "Email Sent Successfully"+forgotresp, Toast.LENGTH_LONG).show();

                    Intent imodule=new Intent(ForgotPasswordActivity.this,MainActivity.class);
                    startActivity(imodule);
                }

            }

            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(context, "failure", Toast.LENGTH_SHORT).show();

            }
        });





    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;
         /*   case R.id.finjan:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/
            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;


        }
        return false;
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }



}
