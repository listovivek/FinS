package com.myappilication.xpress.finjan2017;

/**
 * Created by sureshmano on 3/20/2017.
 */

public class calclistdatas {


    private String course_calculator;

    public calclistdatas(String course_calculator){

       this.course_calculator = course_calculator;

    }


    public String getCourse_calculator() {
        return course_calculator;
    }

    public void setCourse_calculator(String course_calculator) {
        this.course_calculator = course_calculator;
    }
}
