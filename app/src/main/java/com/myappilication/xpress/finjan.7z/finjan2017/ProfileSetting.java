package com.myappilication.xpress.finjan2017;

import android.app.ActionBar;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;
import com.myappilication.xpress.finjan2017.models.login.helpers.NetConnectionDetector;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;
import com.myappilication.xpress.finjan2017.models.login.login.loginreq;
import com.myappilication.xpress.finjan2017.models.login.login.loginresp;
import com.myappilication.xpress.finjan2017.models.login.profileedit.profilereq;
import com.myappilication.xpress.finjan2017.models.login.profileedit.profileresp;
import com.myappilication.xpress.finjan2017.models.login.profileupdate.profileupdatereq;
import com.myappilication.xpress.finjan2017.models.login.profileupdate.profileupdateresp;
import com.myappilication.xpress.finjan2017.models.login.pushnotification.NotifyConfig;
import com.myappilication.xpress.finjan2017.models.login.settings.settingsreq;
import com.myappilication.xpress.finjan2017.models.login.settings.settingsresp;
import com.myappilication.xpress.finjan2017.webservice.RxApi;
import com.myappilication.xpress.finjan2017.webservice.RxClient;

import java.util.ArrayList;
import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

import static android.R.attr.onClick;

public class ProfileSetting extends AppCompatActivity {



    Button btn_save_changes, btn_edit_profile;

    EditText et_emailid, et_fname, et_lname, et_username, et_password, et_companyname;

    Boolean isSearchtoakenExpired = false;



    NetConnectionDetector NCD;
    Context context;
    ProgressBar progressBar;
    Intent newintent;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    Toolbar toolbar;
    ImageButton imageButton;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_edit);

        NCD = new NetConnectionDetector();

        context = getApplicationContext();

        progressBar = (ProgressBar) findViewById(R.id.progressBar_cyclic);

        progressBar.setVisibility(View.VISIBLE);


        btn_save_changes = (Button) findViewById(R.id.button_save_changes);

        btn_edit_profile = (Button) findViewById(R.id.btn_edit_profile);

        et_fname = (EditText) findViewById(R.id.profile_edit_fname);
        et_lname = (EditText) findViewById(R.id.profile_edit_lastname);
        et_username = (EditText) findViewById(R.id.profile_username);
        et_password = (EditText) findViewById(R.id.profile_password);
        et_companyname = (EditText) findViewById(R.id.profile_companyname);









        et_emailid = (EditText) findViewById(R.id.profile_emailid);

        et_fname.setEnabled(false);
        et_lname.setEnabled(false);
        et_username.setEnabled(false);
        et_password.setEnabled(false);
        et_companyname.setEnabled(false);
        et_emailid.setEnabled(false);

        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();



       /* Boolean Speditprofilesuccess = sharedpreferences.getBoolean(SharedPrefUtils.Speditprofilesuccess, false);

        if (Speditprofilesuccess) {

            Intent newin = new Intent(ProfileSetting.this, FaqActivity.class);
            startActivity(newin);

            //Toast.makeText(getApplicationContext(),"Profile editied Successfully", Toast.LENGTH_LONG).show();
        }*/


        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        imageButton = (ImageButton) findViewById(R.id.tb_normal_back);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });


        getprofiledatas();






        btn_edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                getprofiledatas();

                et_fname.setEnabled(true);
                et_lname.setEnabled(true);
                et_username.setEnabled(true);
                et_password.setEnabled(true);
                et_emailid.setEnabled(true);



            }
        });


        btn_save_changes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              /*  Toast.makeText(context, "fd"+sharedpreferences.getString(SharedPrefUtils.SpRememberToken, ""), Toast.LENGTH_LONG).show();*/
                ArrayList<String> tm = new ArrayList<String>();
                tm.add("1");
                tm.add("2");
                tm.add("3");

              RxClient.get(ProfileSetting.this).Updateprofile(sharedpreferences.
                      getString(SharedPrefUtils.SpRememberToken, ""),
                      new profileupdatereq(sharedpreferences.getString(SharedPrefUtils.SpId,""),
                        sharedpreferences.getString(SharedPrefUtils.SpUserId,""),
                              et_username.getText().toString().trim(),
                        et_fname.getText().toString().trim(),
                              et_lname.getText().toString().trim(),
                              et_emailid.getText().toString().trim(),
                        et_companyname.getText().toString().trim(),
                              sharedpreferences.getString(SharedPrefUtils.SpExpDate,""),
                      tm), new Callback<profileupdateresp>() {
                    @Override
                    public void success(profileupdateresp profileupdateresp, Response response) {

                        Toast.makeText(ProfileSetting.this,"User Details Successfully updated",Toast.LENGTH_LONG).show();

                        if (profileupdateresp.getStatus().equals("200")){

                            editor.putString(SharedPrefUtils.SpUserName,et_username.getText().toString());
                            editor.putString(SharedPrefUtils.SpFirstname,et_fname.getText().toString());
                            editor.putString(SharedPrefUtils.SpFirstname,et_lname.getText().toString());
                            editor.putString(SharedPrefUtils.SpEmail,et_emailid.getText().toString());
                            editor.putString(SharedPrefUtils.SpCompanyName,et_companyname.getText().toString());
                            editor.commit();


                            Intent imodule=new Intent(ProfileSetting.this,ModuleFinJan.class);
                            startActivity(imodule);
                            finish();
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {

                        isSearchtoakenExpired = false;

                        mtd_refresh_token();

                       // Toast.makeText(ProfileSetting.this,"failure",Toast.LENGTH_LONG).show();
                    }
                });

               /* RxClient.get(context).Editprofile(remember_token, new profilereq(sharedpreferences.getString(SharedPrefUtils.SpEmail,"") ), new Callback<profileresp>()*/








                /*RxClient.get(context).Updateprofile(new profileupdatereq(et_username.getText().toString().trim(),
                        et_fname.getText().toString().trim(),et_lname.getText().toString().trim(),
                        et_emailid.getText().toString().trim(),et_companyname.getText().toString().trim()),new Callback<profileupdateresp>

                }
              /*  newintent = new Intent(ProfileSetting.this, ModuleFinJan.class);
                startActivity(newintent);*/

            }
        });


       /* List<String> categories = new ArrayList<String>();
        categories.add("FinJan Modular");
        categories.add("English");
        categories.add("Kannada");
        categories.add("Tamil");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);*/


        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onBackPressed() {

       this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();
                finish();
                return true;
            case R.id.profile_menu:
                startActivity(new Intent(getApplicationContext(), ProfileSetting.class));
                finish();
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                finish();
                return true;
            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;
            case R.id.calculator:
                startActivity(new Intent(getApplicationContext(), FinjanCalcModule.class));
                return true;
     /*       case R.id.dashboard_menu:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;*/
       /*     case R.id.finjan_video:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/



        }
        return false;
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }


    private void getprofiledatas(){

        RxClient.get(context).Editprofile(sharedpreferences.getString(SharedPrefUtils.SpRememberToken, ""),
                new profilereq(sharedpreferences.getString(SharedPrefUtils.SpEmail,"") ),
                    new Callback<profileresp>() {

            @Override
            public void success(profileresp profileresp, Response response) {


                if (profileresp.getStatus().equals("200")){

                  progressBar.setVisibility(View.GONE);
                  editor.putString(SharedPrefUtils.Splastname,profileresp.getResult().getInfo().getLists().getFirstname());


                   editor.putString(SharedPrefUtils.SpFirstname,profileresp.getResult().getInfo().getLists().getPassword());
                   editor.putString(SharedPrefUtils.SpEmail, profileresp.getResult().getInfo().getLists().getEmail());
                   editor.putString(SharedPrefUtils.SpCompanyName, profileresp.getResult().getInfo().getLists().getCompany_name());
                   editor.putString(SharedPrefUtils.SpId,profileresp.getResult().getInfo().getLists().getId());
                   editor.putString(SharedPrefUtils.SpUserId,profileresp.getResult().getInfo().getLists().getUser_id());
                   editor.putString(SharedPrefUtils.SpUserName,profileresp.getResult().getInfo().getLists().getName());
                   editor.putString(SharedPrefUtils.SpExpDate,profileresp.getResult().getInfo().getLists().getExp_date());
               /* editor.putString(SharedPrefUtils.SpModules,profileresp.getResult().getInfo().getLists().getModules().toString());*/

                   editor.commit();
                   et_fname.setText(profileresp.getResult().getInfo().getLists().getFirstname());
                   et_lname.setText(profileresp.getResult().getInfo().getLists().getLastname());
                   et_username.setText(profileresp.getResult().getInfo().getLists().getName());
                   et_password.setText(profileresp.getResult().getInfo().getLists().getPassword());
                   et_emailid.setText(profileresp.getResult().getInfo().getLists().getEmail());
                    for (int i = 0; i < profileresp.getResult().getInfo().getCorporates().length; i++) {
                        if(profileresp.getResult().getInfo().getLists().getCompany_name().equals( profileresp.getResult().getInfo().getCorporates()[i].getId())){
                            et_companyname.setText(profileresp.getResult().getInfo().getCorporates()[i].getCompany_name());
                        }
                    }


}
else if(profileresp.getStatus().equals("402")){

    isSearchtoakenExpired = false;

    mtd_refresh_token();

}







            }

            @Override
            public void failure(RetrofitError error) {
                isSearchtoakenExpired = false;

                mtd_refresh_token();

            }
        });




    }


    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("ProfileSetting Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }

    /*public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }*/


    @Override
    protected void onResume() {
        super.onResume();

        // register GCM registration complete receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(NotifyConfig.REGISTRATION_COMPLETE));

        // register new push message receiver
        // by doing this, the activity will be notified each time a new message arrives
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(NotifyConfig.PUSH_NOTIFICATION));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        super.onPause();
    }

    private void mtd_refresh_token() {
       // Toast.makeText(context, "expired", Toast.LENGTH_SHORT).show();
        RxClient.get(ProfileSetting.this).Login(new loginreq(sharedpreferences.getString(SharedPrefUtils.SpPassword, ""),sharedpreferences.getString(SharedPrefUtils.SpEmail, "")), new Callback<loginresp>() {
            @Override
            public void success(loginresp loginresp, Response response) {




                if (loginresp.getStatus().equals("200")){


                    //Toast.makeText(getApplicationContext(),"sucesss"+loginresp.getToken().toString(),Toast.LENGTH_LONG).show();

                    editor.putString(SharedPrefUtils.SpRememberToken,loginresp.getToken().toString());

                    editor.commit();
                    /*adapter.notifyDataSetChanged();*/
                    if(isSearchtoakenExpired) {
                        getprofiledatas();
                    }
                }







            }

            @Override
            public void failure(RetrofitError error) {

              //  Toast.makeText(getApplicationContext(),"Wrong Username And Password",Toast.LENGTH_LONG).show();

            }
        });

    }
}
