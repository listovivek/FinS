package com.myappilication.xpress.finjan2017.mcqevalutiontest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.myappilication.xpress.finjan2017.ActivityEvaluation;

import com.myappilication.xpress.finjan2017.R;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.MCQTest;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.McQData;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by suresh on 3/5/17.
 */
public class QuestionActivity extends Activity {


    private RadioButton answer1 = null;
    private RadioButton answer2 = null;
    private RadioButton answer3 = null;
    private RadioButton answer4 = null;
    private RadioGroup answers = null;

    public static int selected[] = null;
    private int correctAns[] = null;
    private int quesIndex = 0;

    ArrayList<String> temp = new ArrayList<>();
    TextView questionNum, question,moduleName;
    Intent in;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mcq_test);

        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();

        moduleName = (TextView) findViewById(R.id.dashboard);
        questionNum = (TextView) findViewById(R.id.questionNumber);
        question = (TextView) findViewById(R.id.qDescription);

        in = getIntent();
        String modName = sharedpreferences.getString("Module_name", "");;
        moduleName.setText(""+ modName);

      /*  String name = intent.getStringExtra("Module_name");
        t3.setText(" " + name);*/

        ArrayList<String> cc = new ArrayList<>();
        ArrayList<String> cc1 = new ArrayList<>();
        ArrayList<String> cc2 = new ArrayList<>();
        ArrayList<String> cc3 = new ArrayList<>();


      /*  for(int i=0; i<McQData.getInstance().getMCQQuestion().size(); i++){
            cc.add(McQData);
        }*/


        answer1 = (RadioButton) findViewById(R.id.opt0);
        answer2 = (RadioButton) findViewById(R.id.opt1);
        answer3 = (RadioButton) findViewById(R.id.opt2);
        answer4 = (RadioButton) findViewById(R.id.opt3);
        answers = (RadioGroup) findViewById(R.id.options);

        selected = new int[McQData.getMcQData().getMCQQuestion().size()];
        Arrays.fill(selected, -1);
        correctAns = new int[McQData.getInstance().getMCQcorrectans().size()];
        Arrays.fill(correctAns, -1);

        this.showQus(0);

        Button next = ((Button) findViewById(R.id.nextBtn));
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               next(v);
            }
        });
        //  next.setText(getString(R.string.nextButton));
        // }
        // disable previous question button if on first question
        if (0 == 1) {
            ((Button) findViewById(R.id.previousBtn)).setEnabled(false);
        } else {
            ((Button) findViewById(R.id.previousBtn)).setEnabled(true);
        }
    }

    private void showQus(int index) {

        answers.check(-1);

        question.setText(McQData.getInstance().getMCQQuestion().get(index));

        answer1.setText(McQData.getInstance().getMCQanswer1().get(index));
        answer2.setText(McQData.getInstance().getMCQanswer2().get(index));
        answer3.setText(McQData.getInstance().getMCQanswer3().get(index));
        answer4.setText(McQData.getInstance().getMCQanswer4().get(index));

        Log.d("",selected[index]+ "");

        if (selected[index] == 0)
            answers.check(R.id.opt0);
        if (selected[index] == 1)
            answers.check(R.id.opt1);
        if (selected[index] == 2)
            answers.check(R.id.opt2);
        if (selected[index] == 3)
            answers.check(R.id.opt3);

        setScoreTitle();


    }

    private void setScoreTitle() {
        questionNum.setText("Questions  "+(quesIndex+1)+ "/" + McQData.getInstance().getMCQQuestion().size());

    }

    private void setAnswer() {
        if (answer1.isChecked())
            selected[quesIndex] = 0;
        if (answer2.isChecked())
            selected[quesIndex] = 1;
        if (answer3.isChecked())
            selected[quesIndex] = 2;
        if (answer4.isChecked())
            selected[quesIndex] = 3;

        Log.d("", Arrays.toString(selected));
        Log.d("",Arrays.toString(correctAns));

    }


    public void previous(View view) {
        setAnswer();
        quesIndex--;
        if (quesIndex < 0){
            quesIndex = 0;
            view.setEnabled(false);
        }else{
            showQus(quesIndex);
        }
    }

    public void next(View view) {

        if(answer1.isChecked() || answer2.isChecked() || answer3.isChecked() || answer4.isChecked()) {
            setAnswer();
            quesIndex++;
            if(quesIndex >= McQData.getInstance().getMCQQuestion().size()){
                quesIndex = McQData.getInstance().getMCQQuestion().size() - 1;
               // Toast.makeText(QuestionActivity.this, "finished", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(QuestionActivity.this, ActivityEvaluation.class);
                startActivity(i);
                this.finish();

                ArrayList<String> cc = new ArrayList<>();
                ArrayList<String> corr = McQData.getInstance().getMCQcorrectans();
                ArrayList<String> finalAns = new ArrayList<String>();
                for(int t=0; t<McQData.getInstance().getMCQQuestion().size(); t++){

                    cc.add(McQData.getInstance().getMCQanswer1().get(t));
                    cc.add(McQData.getInstance().getMCQanswer2().get(t));
                    cc.add(McQData.getInstance().getMCQanswer3().get(t));
                    cc.add(McQData.getInstance().getMCQanswer4().get(t));

                    String userSelectAns = cc.get(selected[t]);
                    finalAns.add(userSelectAns);
                    cc.clear();

                }
                McQData.getInstance().setUserSelectedData(finalAns);
            }else{
                showQus(quesIndex);
            }

        }else{
            Toast.makeText(QuestionActivity.this, "Kindly click any one option", Toast.LENGTH_SHORT).show();
        }


    }
}
