package com.myappilication.xpress.finjan2017.models.login.forget;

/**
 * Created by sureshmano on 3/29/2017.
 */

public class forgotreq {
        String email;



        public forgotreq(String email){

            this.email = email;

        }


}
