package com.myappilication.xpress.finjan2017;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.DecimalFormat;

public class CalcSS extends AppCompatActivity {

    EditText et_sspmt, et_ssyears, et_ssrate, et_14years, et_21years ;
    Button btn_calculate;
    Toolbar toolbar;
    ImageButton imageButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calc_ss);
        et_sspmt = (EditText) findViewById(R.id.calc_sspmt);
        et_ssyears = (EditText) findViewById(R.id.calc_ssyears);
        et_ssrate = (EditText) findViewById(R.id.calc_ssrate);
        et_14years = (EditText) findViewById(R.id.calc_ss14years);

        et_21years = (EditText) findViewById(R.id.calc_ss21years);

        et_14years.setEnabled(false);
        et_21years.setEnabled(false);

        btn_calculate = (Button) findViewById(R.id.calc_calculate);


        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        imageButton = (ImageButton) findViewById(R.id.tb_normal_back);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });








        btn_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mtd_ss_calculation();

                            }


        });













    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();

            case R.id.profile_menu:
                startActivity(new Intent(getApplicationContext(), ProfileSetting.class));
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;
            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;
            case R.id.calculator:
                startActivity(new Intent(getApplicationContext(), FinjanCalcModule.class));
                return true;
           /* case R.id.dashboard_menu:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;*/
           /* case R.id.finjan_video:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/

        }
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }

    private void mtd_ss_calculation() {
        Double ss_pmt,ss_nper,ss_int;


        if (et_sspmt.length() == 0 ){

            et_sspmt.setError("Enter Amount");
            /*Toast.makeText(this, "", Toast.LENGTH_SHORT).show();*/

        }
        else if (et_ssyears.length() == 0){
            et_ssyears.setError("Enter Years");
        }
        else if  (et_ssrate.length() == 0){
            et_ssrate.setError("Enter Interest");
        } else {
            ss_pmt = Double.parseDouble(et_sspmt.getText().toString());
            ss_nper = Double.parseDouble(et_ssyears.getText().toString());


            ss_int = Double.parseDouble(et_ssrate.getText().toString());

            Double ss_per = ss_int/100;
            Integer type =1;
            Integer pv=0;
            Double temp=Math.pow((ss_per+1),ss_nper);
            Double fv = (-ss_pmt*(1+ss_per*type)*(1-temp)/ss_per)-pv*temp;
            Double ss_temp2=Math.pow((ss_per+1),7);
            Double secondres=ss_temp2*fv;


                /*double si = (amount * Interest * yearcount) / 100;*/
            et_14years.setText(new DecimalFormat("##.##").format(fv));
            et_21years.setText(new DecimalFormat("##.##").format(secondres));
        }




    }

}
