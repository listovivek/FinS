package com.myappilication.xpress.finjan2017;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import com.myappilication.xpress.finjan2017.mcqevalutiontest.McQData;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.QuestionActivity;

import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionModularQues;
import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionReq;
import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionResponse;
import com.myappilication.xpress.finjan2017.models.login.faq.Faqlistdatas;
import com.myappilication.xpress.finjan2017.models.login.helpers.NetConnectionDetector;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;
import com.myappilication.xpress.finjan2017.models.login.login.loginreq;
import com.myappilication.xpress.finjan2017.models.login.login.loginresp;
import com.myappilication.xpress.finjan2017.webservice.RxClient;
import com.squareup.picasso.Picasso;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class DashBoard extends AppCompatActivity {


    @SuppressWarnings("deprecation")
    @SuppressLint("SetJavaScriptEnabled")
    Button Download, btn_playvideo, bt_next;
    //final String vidAddress = "http://183.82.33.232:8094/coursevideos/";
    MessageDigest mdEnc = null;
    private String filename = "MySampleFile.txt";
    private String filepath = "MyFileStorage";
    File myInternalFile;
    ProgressDialog pDialog;
    Intent newinetent;
    public ProgressDialog prgDialog;
    // Progress Dialog type (0 - for Horizontal progress bar)
    public static final int progress_bar_type = 0;
    //String remember_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjIsImlzcyI6Imh0dHA6XC9cLzE4My44Mi4zMy4yMzI6ODA5NFwvYXBpXC9sb2dpbiIsImlhdCI6MTQ5MDc4Mjg4MiwiZXhwIjoxNDkwNzg2NDgyLCJuYmYiOjE0OTA3ODI4ODIsImp0aSI6IjE2ZGQwYTEzYTE3NDUyN2IzOGY1MjczZmQ5MGJiMTVmIn0.s0WeAohakMPYIBJ5PVWbOGd6d3iaH7ebpVD-X4WcrtM";
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    byte[] decrpt;
    static Context ctx;
    final List<String> videoNames = new ArrayList<String>();
    TextView t3;
    int t5;
    List<EvalutionModularQues> quesList;
    List<EvalutionModularQues> quesListDB;
    int score=0;
    int qid=0;
    EvalutionModularQues currentQ;
    DbHelper db = new DbHelper(this);
    NetConnectionDetector NDC;

    String Search_query = "";
    SearchView searchviewfaq;
    ArrayList<String>Module=new ArrayList<>();
    ArrayList<String>s=new ArrayList<>();
    ProgressBar progressBar;
    VideoView vidView;
    String result;
    ArrayList<HashMap<String, Object>> MyArrList = new ArrayList<HashMap<String, Object>>();
    String filename_to_dl;
    int bytesRead, bytesAvailable, bufferSize;
    ArrayList<String> mcq_id = new ArrayList<>();
    String modular;
    String m,modul;
    int sentBytes = 0;
    long fileSize1;
    TextView tv_finjan_test;
    String Module_id;
    ArrayList<String> mcq_Id = new ArrayList<String>();
    ArrayList<String> mcq_question = new ArrayList<String>();
    ArrayList<String> mcq_answer1 = new ArrayList<String>();
    ArrayList<String> mcq_answer2 = new ArrayList<String>();
    ArrayList<String> mcq_answer3 = new ArrayList<String>();
    ArrayList<String> mcq_answer4 = new ArrayList<String>();
    ArrayList<String> mcq_correct_ans = new ArrayList<>();
    ArrayList<String> mcq_ID = new ArrayList<String>();
    ArrayList<String> Calc = new ArrayList<String>();

    Toolbar toolbar;
    ImageButton imageButton;


    Context context;


    /**  this.email = email;
     this.mcq_id = mcq_id;
     this.user_ans = user_ans;
     this.modular = modular;
     this.score = score;
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboardnew);

       /* recyclerView = (RecyclerView) findViewById(R.id.calc_card_recycler_view);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);*/


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        imageButton = (ImageButton) findViewById(R.id.tb_normal_back);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        final Intent intent = getIntent();
        String cali =  intent.getStringExtra("cal");
        Toast.makeText(getApplicationContext(), ""+cali, Toast.LENGTH_SHORT).show();
         Module_id = sharedpreferences.getString("name", "");

      //  Toast.makeText(DashBoard.this, "Module_id" + Module_id, Toast.LENGTH_SHORT).show();
        // String Lang_id=intent.getStringExtra("Lang_id");
        // Log.d("Lang",Lang_id);
        // Log.d("Module_id.....",Module_id);
        filename_to_dl =  sharedpreferences.getString("Filename", "");
     //   Toast.makeText(getApplicationContext(), "Filename----" + filename_to_dlToast.LENGTH_LONG).show();
        progressBar = (ProgressBar) findViewById(R.id.progress);
        final String enc_url = sharedpreferences.getString("Encrypt_video", "");
        //final String video_type=intent.getStringExtra("Video_type");

        final String play_url = sharedpreferences.getString("video_name", "");
        final String vtype = sharedpreferences.getString("Video_type", "");

        final String img = sharedpreferences.getString("Video_image", "");



//        Log.d("Video_im", img);



        // Toast.makeText(DashBoard.this, "Video_type" + vtype, Toast.LENGTH_SHORT).show();

  sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        final ImageView imageView = (ImageView) findViewById(R.id.imageView1);

        // imageView.setScaleType(ImageView.ScaleType.FIT_XY);

        Picasso.with(getApplicationContext()).load(img).resize(2600, 1700).centerCrop().into(imageView);
       // Toast.makeText(DashBoard.this, "Video_type" + vtype, Toast.LENGTH_SHORT).show();

        /* editor.putString(SharedUtils.SpModuleId,moduleId);
        editor.commit();*/

      /*  DisplayMetrics metrics = new DisplayMetrics(); getWindowManager().getDefaultDisplay().getMetrics(metrics);
        android.widget.LinearLayout.LayoutParams params = (android.widget.LinearLayout.LayoutParams) vidView.getLayoutParams();
        params.width =  metrics.widthPixels;
        params.height = metrics.heightPixels;
        params.leftMargin = 0;
        vidView.setLayoutParams(params);*/
        //  String s="coursevideos/Encrypt_module8.mp4";

        //Toast.makeText(getApplicationContext(), "result"+result, Toast.LENGTH_SHORT).show();
        t3 = (TextView) findViewById(R.id.t1);
        String name = sharedpreferences.getString("Module_name", "");
        t3.setText(" " + name);

        tv_finjan_test = (TextView) findViewById(R.id.text_finjan_test);
        String testfinjan = sharedpreferences.getString("Module_name", "");

        tv_finjan_test.setText(" " + testfinjan);

        context = getApplicationContext();
        NDC = new NetConnectionDetector();
        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File directory = contextWrapper.getDir(filepath, Context.MODE_PRIVATE);
        myInternalFile = new File(directory, filename);
        final VideoView vidView = (VideoView) findViewById(R.id.video);
        Download = (Button) findViewById(R.id.btn_downloadnew);

       /* MediaController mediacontroller = new MediaController(
                DashBoard.this);
        mediacontroller.setAnchorView(vidView);
        // Get the URL from String VideoURL
        Uri video = Uri.parse(play_url);
        vidView.setMediaController(mediacontroller);
        vidView.setVideoURI(video);
        vidView.start();
*/


        File file = new File(Environment.getExternalStorageDirectory() + filename_to_dl);
        //File fil = new File(Environment.getExternalStorageDirectory() + filename_to_dl+"e");
     /*   long fileSize = file.length();
        fileSize1 = filename_to_dl.length();
*/

        if (file.exists()) {
            Download.setVisibility(View.INVISIBLE);
            new Handler().postDelayed(
                    new Runnable() {
                        @Override
                        public void run() {

                            Download.performClick();
                        }
                    },
                    5000
            );
        }

        btn_playvideo = (Button) findViewById(R.id.btn_playvideo);


        vidView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // TODO Auto-generated method stub
                progressBar.setVisibility(View.VISIBLE);

                mp.start();
                vidView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

                if (mp.isPlaying()) {
                    btn_playvideo.setVisibility(View.INVISIBLE);
                    progressBar.setVisibility(View.GONE);
                }
                mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                    @Override
                    public void onVideoSizeChanged(MediaPlayer mp, int arg1,
                                                   int arg2) {
                        // TODO Auto-generated method stub


                    }
                });
            }
        });


        bt_next = (Button) findViewById(R.id.take_test);


        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quesList = db.getAllQuestions();
                if (NDC.isConnected(context)) {
                    getSearchData();

                } else if(quesList != null){




                    for(EvalutionModularQues dc : quesList){
                        mcq_Id.add(dc.getMcq_id());
                        mcq_answer1.add(dc.getMcq_ans1());
                        mcq_answer2.add(dc.getMcq_ans2());
                        mcq_answer3.add(dc.getMcq_ans3());
                        mcq_answer4.add(dc.getMcq_ans4());
                        mcq_question.add(dc.getMcq_qus());
                        mcq_correct_ans.add(dc.getCorrect_ans());

                        McQData.getInstance().setMCQid(mcq_Id);
                        McQData.getInstance().setMCQQuestion(mcq_question);
                        McQData.getInstance().setMCQanswer1(mcq_answer1);
                        McQData.getInstance().setMCQanswer2(mcq_answer2);
                        McQData.getInstance().setMCQanswer3(mcq_answer3);
                        McQData.getInstance().setMCQanswer4(mcq_answer4);
                        McQData.getInstance().setMCQcorrectans(mcq_correct_ans);
                    }

                    newinetent = new Intent(DashBoard.this, QuestionActivity.class);
                    startActivity(newinetent);

                }else{
                    Toast.makeText(context, "Kindly check your network connection", Toast.LENGTH_LONG).show();
                }

                ;
            }
        });

        btn_playvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(30);

                //  if (Integer.parseInt(Lang_id)==Integer.parseInt(Module_id)) {

                imageView.setVisibility(View.INVISIBLE);
                MediaController mediacontroller = new MediaController(
                        DashBoard.this);
                mediacontroller.setAnchorView(vidView);
                // Get the URL from String VideoURL
                Uri video = Uri.parse(play_url);
                vidView.setMediaController(mediacontroller);
                vidView.setVideoURI(video);
                vidView.start();

                //  t3.setText("Your OutPut"+position);
            }


            FileOutputStream fos = null;

            {
                try {
                    fos = new FileOutputStream(myInternalFile);
                    fos.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        });


        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                File file = new File(Environment.getExternalStorageDirectory() + filename_to_dl);
                //File fil = new File(Environment.getExternalStorageDirectory() + filename_to_dl+"e");
                long fileSize = file.length();
                fileSize1 = filename_to_dl.length();


                if (file.exists()) {
                    Download.setVisibility(View.INVISIBLE);
                    new Offlinevideo().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                }
                // If the Music File doesn't exist in SD card (Not yet downloaded)e} //if(video_type.equals("yes")) {
                else if (vtype.equals("yes")) {

                    // Download.setVisibility(View.VISIBLE);

                    Toast.makeText(getApplicationContext(), "File doesn't exist under SD Card, downloading Mp3 from Internet", Toast.LENGTH_LONG).show();
                    // Trigger Async Task (onPreExecute method)
                    new DownloadMusicfromInternet().execute(enc_url);
                } else {
                    Download.setVisibility(View.INVISIBLE);
                    imageView.setVisibility(View.INVISIBLE);

                    MediaController mediacontroller = new MediaController(
                            DashBoard.this);
                    mediacontroller.setAnchorView(vidView);
                    // Get the URL from String VideoURL
                    Uri video = Uri.parse(enc_url);
                    vidView.setMediaController(mediacontroller);
                    vidView.setVideoURI(video);
                    vidView.start();
                }
                ;

            }








            // Async Task Class
            class DownloadMusicfromInternet extends AsyncTask<String, String, String> {

                // Show Progress bar before downloading Music
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    // Shows Progress Bar Dialog and then call doInBackground method
                  /*  showDialog(progress_bar_type);
                    ProgressBar progressBar;*/
                    progressBar.setVisibility(View.VISIBLE);
                }

                // Download Music File from Internet
                @Override
                protected String doInBackground(String... f_url) {
                    int count;
                    try {

                        // Log.d("result",result);
                        URL url = new URL(f_url[0]);
                        URLConnection conection = url.openConnection();
                        conection.connect();

                        // Get Music file length
                        int lenghtOfFile = conection.getContentLength();
                        // input stream to read file - with 8k buffer
                        InputStream input = new BufferedInputStream(url.openStream(), 10 * 1024);
                        // Output stream to write file in SD card
                        // String fileName = url.getFile(url.lastIndexOf('/')+1, url.length() )

                        Log.d("FLN", "" + filename_to_dl);

                        // filename_to_dl = "/Encrypt_finjan_chap_2_kannada.mp4";

                        OutputStream output = new FileOutputStream(Environment.getExternalStorageDirectory() + filename_to_dl);

                        byte data[] = new byte[1024];
                        long total = 0;
                        while ((count = input.read(data)) != -1) {
                            total += count;
                            // Publish the progress which triggers onProgressUpdate method
                            publishProgress("" + (int) ((total * 100) / lenghtOfFile));

                            // Write data to file
                            output.write(data, 0, count);
                        }
                        // Flush output
                        output.flush(); decrpt = decrypt();
                        playMusic(decrpt);
                        // Close streams
                        output.close();
                        input.close();
                    } catch (Exception e) {
                    }
                    return null;
                }

                /*  protected void onProgressUpdate(String... progress) {
                      // Set progress percentage
                      prgDialog.setProgress(Integer.parseInt(progress[0]));
                  }*/
                // While Downloading Music File
                protected void onProgressUpdate(String... progress) {
                    // Set progress percentage
                    progressBar.setProgress(Integer.parseInt(progress[0]));

                }


                // Once Music File is downloaded
                @Override
                protected void onPostExecute(String file_url) {
                    // Dismiss the dialog after the Music file was downloaded
                 /*   dismissDialog(progress_bar_type);*/
                    progressBar.setVisibility(View.GONE);


                    Toast.makeText(getApplicationContext(), "Download complete, playing Music", Toast.LENGTH_LONG).show();
                    // Play the music

                    new Offlinevideo().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

                }
            }

            class Offlinevideo extends AsyncTask<String, String, String> {
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    // Shows Progress Bar Dialog and then call doInBackground method
                    //  showDialog(progress_bar_type);
                    //   ProgressBar progressBar;
                    progressBar.setVisibility(View.VISIBLE);
            /*        prgDialog = new ProgressDialog(DashBoard.this);
                    prgDialog.setMessage("Decrypt processing ........");
                    prgDialog.setIndeterminate(false);
                    //  prgDialog.setMax(100);
                    prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    prgDialog.setCancelable(false);
                    prgDialog.show();*/

                }

                // Download Music File from Internet
                @Override
                protected String doInBackground(String... f_url) {
                    int count;
                    try {
                        decrpt = decrypt();

                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.d("Error", String.valueOf(e));

                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    } catch (NoSuchPaddingException e) {
                        e.printStackTrace();
                    } catch (InvalidKeyException e) {
                        e.printStackTrace();
                        Log.d("Error", String.valueOf(e));
                    }
                    return null;

                }
                protected void onPostExecute(String file_url) {
                    // Dismiss the dialog after the Music file was downloaded
                    //dismissDialog(progress_bar_type);
                    //Toast.makeText(getApplicationContext(), "Download complete, playing Music", Toast.LENGTH_LONG).show();
                    // Play the music
                   // prgDialog.cancel();
                    playMusic(decrpt);
                    progressBar.setVisibility(View.INVISIBLE);

                }

            }

            protected void playMusic(byte[] mp3SoundByteArray) {
                // Read Mp3 file present under SD card
                Uri viduri = Uri.parse(Environment.getExternalStorageDirectory() + "/dec.mp4");
                MediaController mediacontroller = new MediaController(
                        DashBoard.this);
                try {
                    mediacontroller.setAnchorView(vidView);
                    imageView.setVisibility(View.INVISIBLE);
                    // Get the URL from String VideoURL
                    Uri cv = Uri.parse(String.valueOf(viduri));
                    vidView.setMediaController(mediacontroller);
                    vidView.setVideoURI(cv);
                    vidView.start();
                    vidView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        public void onCompletion(MediaPlayer mp) {
                            // TODO Auto-generated method stub
                            // Once Music is completed playing, enable the button
                            Download.setEnabled(true);
                            // Toast.makeText(getApplicationContext(), "Music completed playing", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (IllegalArgumentException e)

                {
                    //  Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                } catch (
                        SecurityException e
                        )

                {
                    //  Toast.makeText(getApplicationContext(), "URI cannot be accessed, permissed needed", Toast.LENGTH_LONG).show();
                } catch (
                        IllegalStateException e
                        )

                {
                    //    Toast.makeText(getApplicationContext(), "Media Player is not in correct state", Toast.LENGTH_LONG).show();
                }
            }
        });
     /*   File file = new File(Environment.getExternalStorageDirectory() + filename_to_dl);
        //File fil = new File(Environment.getExternalStorageDirectory() + filename_to_dl+"e");
        long fileSize = file.length();*/
       /* fileSize1 = filename_to_dl.length();


            new Handler().postDelayed(
                    new Runnable() {
                        @Override
                        public void run() {

                            Download.performClick();
                        }
                    },
                    5000

        if (file.exists()) {
            Download.setVisibility(View.INVISIBLE);

            new Handler().postDelayed(
                    new Runnable() {
                        @Override
                        public void run() {

                            Download.performClick();
                        }
                    },
                    5000
            );
        }    );*/

    }

    void encrypt() throws IOException, NoSuchAlgorithmException,
            NoSuchPaddingException, InvalidKeyException {
        // Here you read the cleartext.
        File extStore = Environment.getExternalStorageDirectory();

        FileInputStream fis = new FileInputStream(extStore + filename_to_dl);
        Log.d("FileInputStream", String.valueOf(fis));

    //    Toast.makeText(this,"Encrypt"+fis,Toast.LENGTH_SHORT).show();
        // This stream write the encrypted text. This stream will be wrapped by
        // another stream.
        FileOutputStream fos = new FileOutputStream(extStore + filename_to_dl);
        Log.d("FileOutputStream", String.valueOf(fos));

        // Length is 16 byte
        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(),
                "AES");
        // Create cipher
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks);
        // Wrap the output stream
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);
        // Write bytes
        int b;

        byte[] d = new byte[10240];

        while ((b = fis.read(d)) != -1) {
            cos.write(d, 0, b);
        }
        // Flush and close streams.
        cos.flush();
        cos.close();
        fis.close();



    }
/*    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case progress_bar_type:
                prgDialog = new ProgressDialog(DashBoard.this);
                prgDialog.setMessage("Downloading  file. Please wait...");
                prgDialog.setIndeterminate(false);
                prgDialog.setMax(100);
                prgDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                prgDialog.setCancelable(true);
                prgDialog.show();
                return prgDialog;
            default:
                return null;
        }
    }*/


    byte[] decrypt ()throws IOException, NoSuchAlgorithmException,
            NoSuchPaddingException, InvalidKeyException {

        int VideoI = 1;
        //String s="/Android/data/com.example.balasri.finjonn/data/";
        File extStore = Environment.getExternalStorageDirectory();
        //   Uri u = Uri.parse("android.resource://" + DashBoard.ctx.getPackageName() + "/" + videoNames.get(VideoI));
        FileInputStream fis = new FileInputStream(extStore + filename_to_dl);
        Log.d("DecFileInputStream", String.valueOf(fis));

        FileOutputStream fos = new FileOutputStream(extStore + "/dec.mp4");
        Log.d("DecFileOutputStream", String.valueOf(fos));

        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(),
                "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, sks);
        CipherInputStream cis = new CipherInputStream(fis, cipher);

        int b;
        byte[] d = new byte[10240];
        long total=0;
        while ((b = cis.read(d)) != -1) {
            total+=b;
            // publishProgress("" + (int) ((total * 100) / fileSize1));

            fos.write(d, 0, b);

        }
        //  Toast.makeText(DashBoard.this, fos.toString(), Toast.LENGTH_LONG).show();
        fos.flush();
        fos.close();


        cis.close();

        // String path = android.os.Environment.getExternalStorageDirectory().getPath()+"/bb.mp4";


        return d;
    }


    public void getSearchData() {
        RxClient.get(DashBoard.this).Evalution(sharedpreferences.getString(SharedPrefUtils.SpRememberToken, ""),
                new EvalutionReq(sharedpreferences.getString(SharedPrefUtils.SpEmail, "")),
                new Callback<EvalutionResponse>() {
                    @Override
                    public void success(EvalutionResponse evalutionResponse, Response response) {

                        if (evalutionResponse.getStatus().equals("200")) {

                            EvalutionModularQues[] resDownloadCourse = evalutionResponse.getResult().getInfo().getModularQus();
                            db.onDelete();


                            for (EvalutionModularQues dc : resDownloadCourse) {
                                if (Module_id.equals(dc.getModular())) {

                                    mcq_Id.add(dc.getMcq_id());
                                    mcq_question.add(dc.getMcq_qus());
                                    mcq_answer1.add(dc.getMcq_ans1());
                                    mcq_answer2.add(dc.getMcq_ans2());
                                    mcq_answer3.add(dc.getMcq_ans3());
                                    mcq_answer4.add(dc.getMcq_ans4());
                                    mcq_correct_ans.add(dc.getCorrect_ans());



                                    McQData.getInstance().setMCQid(mcq_Id);
                                    McQData.getInstance().setMCQQuestion(mcq_question);
                                    McQData.getInstance().setMCQanswer1(mcq_answer1);
                                    McQData.getInstance().setMCQanswer2(mcq_answer2);
                                    McQData.getInstance().setMCQanswer3(mcq_answer3);
                                    McQData.getInstance().setMCQanswer4(mcq_answer4);
                                    McQData.getInstance().setMCQcorrectans(mcq_correct_ans);


                                    // quesList.add(dc);

                                    //db.addQuestion(quesList);

                                    // Toast.makeText(getApplicationContext(), "Result" +quesList, Toast.LENGTH_LONG).show();
                                    // Log.d("Ques", String.valueOf(quesList));
                                    //quesList = db.getAllQuestions();
                                    // currentQ = quesList.get(qid);


                                }
                            }

                            if(mcq_question.size() != 0 && mcq_question.size() > 0){
                                db.addQuestion(mcq_question,
                                        mcq_answer1, mcq_answer2, mcq_answer3, mcq_answer4, mcq_correct_ans);

                                quesList = db.getAllQuestions();
                                newinetent = new Intent(DashBoard.this, QuestionActivity.class);

                                startActivity(newinetent);
                                finish();
                            }else{
                                Toast.makeText(DashBoard.this, "No response from service", Toast.LENGTH_SHORT).show();
                            }


                        }

                    }
                    @Override
                    public void failure(RetrofitError error) {
                        Toast.makeText(getApplicationContext(), "Result" + error, Toast.LENGTH_LONG).show();

                    }

                });
    }



    protected void onStart() {
        super.onStart();
        //   Toast.makeText(this, "onStart", Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onResume() {
        super.onResume();
        //  Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //  Toast.makeText(this, "onRestart", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        // Toast.makeText(this, "onPause", Toast.LENGTH_SHORT).show();
        Uri viduri = Uri.parse(Environment.getExternalStorageDirectory() + "/dec.mp4");

        //  File patternDirectory = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString()+"/sdcard:e.mp4");
        // patternDirectory.mkdirs();
        File auxFile = new File(viduri.toString());

        auxFile.delete();

        super.onPause();
        // create temp file that will hold byte array


    }


    @Override
    protected void onStop() {
      //  Toast.makeText(this, "onStop", Toast.LENGTH_SHORT).show();
        Uri viduri = Uri.parse(Environment.getExternalStorageDirectory() + "/dec.mp4");
        progressBar.setVisibility(View.GONE);

        //  File patternDirectory = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString()+"/sdcard:e.mp4");
        // patternDirectory.mkdirs();
        File auxFile = new File(viduri.toString());

        auxFile.delete();
        // Tried reusing instance of media player

        super.onStop();
    }
    // create temp file that will hold byte array

    // but that resulted in system crashes...



    private void mtd_refresh_token() {
       /* Toast.makeText(context, "expired", Toast.LENGTH_SHORT).show();*/
        RxClient.get(DashBoard.this).Login(new loginreq(sharedpreferences.getString(SharedPrefUtils.SpEmail, ""),sharedpreferences.getString(SharedPrefUtils.SpPassword, "")), new Callback<loginresp>() {
            @Override
            public void success(loginresp loginresp, Response response) {




                if (loginresp.getStatus().equals("200")){


                    Toast.makeText(getApplicationContext(),"sucesss"+loginresp.getToken().toString(),Toast.LENGTH_LONG).show();

                    editor.putString(SharedPrefUtils.SpRememberToken,loginresp.getToken().toString());

                    editor.commit();
                    /*adapter.notifyDataSetChanged();*/

                }
            }





            @Override
            public void failure(RetrofitError error) {

                Toast.makeText(getApplicationContext(),"Wrong Username And Password",Toast.LENGTH_LONG).show();

            }
        });

    }

    public void onBackPressed()
    {
        super.onBackPressed(); // this can go before or after your stuff below
        // do your stuff when the back button is pressed
        filename_to_dl="";
        finish();
        // super.onBackPressed(); calls finish(); for you

        // clear your SharedPreferences

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.profile_menu:
                startActivity(new Intent(getApplicationContext(), ProfileSetting.class));
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;
            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;
            case R.id.calculator:
                startActivity(new Intent(getApplicationContext(), FinjanCalcModule.class));
                return true;
           /* case R.id.dashboard_menu:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;*/
          /*  case R.id.finjan_video:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/



        }
        return false;
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }


}
