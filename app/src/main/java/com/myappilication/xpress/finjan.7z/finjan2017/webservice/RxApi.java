package com.myappilication.xpress.finjan2017.webservice;

import com.google.android.gms.auth.TokenData;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.McqTestReq;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.McqTestResp;
import com.myappilication.xpress.finjan2017.models.login.DownloadFinjan.DownloadFinjanReq;
import com.myappilication.xpress.finjan2017.models.login.DownloadFinjan.DownloadFinjanResponse;
import com.myappilication.xpress.finjan2017.models.login.FinjanVideo.FinjanReq;
import com.myappilication.xpress.finjan2017.models.login.FinjanVideo.FinjanResponse;

import com.myappilication.xpress.finjan2017.models.login.Result.ResultReq;
import com.myappilication.xpress.finjan2017.models.login.Result.ResultResponse;
import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboardResponse;
import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboradReq;
import com.myappilication.xpress.finjan2017.models.login.download.DownloadReq;
import com.myappilication.xpress.finjan2017.models.login.download.DownloadResponse;
import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionReq;
import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionResponse;
import com.myappilication.xpress.finjan2017.models.login.faq.faqreq;
import com.myappilication.xpress.finjan2017.models.login.faq.faqresp;
import com.myappilication.xpress.finjan2017.models.login.forget.forgotreq;
import com.myappilication.xpress.finjan2017.models.login.forget.forgotresp;
import com.myappilication.xpress.finjan2017.models.login.login.loginreq;
import com.myappilication.xpress.finjan2017.models.login.login.loginresp;
import com.myappilication.xpress.finjan2017.models.login.profileedit.profilereq;
import com.myappilication.xpress.finjan2017.models.login.profileedit.profileresp;
import com.myappilication.xpress.finjan2017.models.login.profileupdate.profileupdatereq;
import com.myappilication.xpress.finjan2017.models.login.profileupdate.profileupdateresp;
import com.myappilication.xpress.finjan2017.models.login.searchfaq.searchreq;
import com.myappilication.xpress.finjan2017.models.login.searchfaq.searchresp;
import com.myappilication.xpress.finjan2017.models.login.settings.settingsreq;
import com.myappilication.xpress.finjan2017.models.login.settings.settingsresp;

import java.util.ArrayList;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.Header;
import retrofit.http.POST;

/**
 * Created by sureshmano on 3/7/2017.
 */

public interface RxApi {

    @POST("/login")
    void Login(@Body loginreq body, Callback<loginresp> callback);

    @POST("/getUsersScores")
    void submit(@Header("Authorization") String authToken, @Body McqTestReq body, Callback<McqTestResp> callback);


    @POST("/editProfile")
   void Editprofile(@Header("Authorization") String authToken,@Body profilereq body, Callback<profileresp> callback);

    @POST("/updateProfile")
    void Updateprofile(@Header("Authorization") String authToken,
                       @Body profileupdatereq body,Callback<profileupdateresp> callback);


    @POST("/userFaq")
    void userFaq(@Header("Authorization") String authToken, @Body faqreq body, Callback<faqresp> callback);

    @POST("/getSearchFieldsForFaq")
    void Searchview(@Header("Authorization") String authToken, @Body searchreq body, Callback<faqresp> callback);

    @POST("/forgotPassword")
    void ForgetPass(@Body forgotreq body, Callback<forgotresp> callback);

    @POST("/userDashboard")
    void DashBoard(@Header("Authorization") String authToken, @Body DashboradReq body, Callback<DashboardResponse> callback);
    @POST("/getManageMcq")
    void Evalution(@Header("Authorization") String authToken, @Body EvalutionReq body, Callback<EvalutionResponse> callback);
    @POST("/downloadVideo")
    void Download(@Header("Authorization") String authToken, @Body DownloadReq body, Callback<DownloadResponse> callback);
    @POST("/getUsersScores")
    void Result(@Body ResultReq body, Callback<ResultResponse> callback);
    @POST("/getUserFinjanvideo")
    void Finjan(@Header("Authorization") String authToken, @Body FinjanReq body, Callback<FinjanResponse> callback);
    @POST("/finjanVideo")
    void DownloadFinjan(@Header("Authorization") String authToken, @Body DownloadFinjanReq body, Callback<DownloadFinjanResponse> callback);
}





   /* @POST("/queryService/myVideosToPlay")
    void MyPrivateLists(@Header("authtoken") String authToken, @Body PrivatePlayListReq body, Callback<PlayListResp> callback);*/


