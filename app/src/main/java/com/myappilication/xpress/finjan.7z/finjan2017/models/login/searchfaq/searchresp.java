package com.myappilication.xpress.finjan2017.models.login.searchfaq;

/**
 * Created by sureshmano on 3/23/2017.
 */

public class searchresp {

    private searchresult result;

    public searchresult getResult ()
    {
        return result;
    }

    public void setResult (searchresult result)
    {
        this.result = result;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [result = "+result+"]";
    }
}
