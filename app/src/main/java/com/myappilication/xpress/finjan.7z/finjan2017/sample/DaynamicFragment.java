package com.myappilication.xpress.finjan2017.sample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;

import com.myappilication.xpress.finjan2017.R;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.McQData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by suresh on 20/4/17.
 */
public class DaynamicFragment extends FragmentActivity {

    ViewPager pager;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mcq_fragment_viewpager);

        final List<Fragment> frag_list = getFragment(10);

        pager = (ViewPager) findViewById(R.id.fragment_viewpager);

        FragmentViewpager pageAdapter = new FragmentViewpager(getSupportFragmentManager(), frag_list);

        pager.beginFakeDrag();
        pager.setAdapter(pageAdapter);



      /*  Button next = (Button) findViewById(R.id.next_button);
        Button prev = (Button) findViewById(R.id.pre_button);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pager.setCurrentItem(pager.getCurrentItem()-1, true);



                //Log.d("name", name);
            }
        });

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pager.setCurrentItem(pager.getCurrentItem()+1, true);

               // String name = (String) ChildFragment.f.getArguments().get(ChildFragment.EXTRA_MESSAGE);

                //String n = ChildFragment.messageTextView.getText().toString();


            }
        });*/
    }

    private List<Fragment> getFragment(int i) {

        List<Fragment> f = new ArrayList<>();

        for(int t=0; t<i; t++){
           // f.add(ChildFragment.newInstance(McQData.getInstance().getMCQQuestion().get(i), "Fragment"+t));
        }




        return f;
    }
}
