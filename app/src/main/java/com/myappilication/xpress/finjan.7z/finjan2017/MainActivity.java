package com.myappilication.xpress.finjan2017;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.myappilication.xpress.finjan2017.models.login.helpers.NetConnectionDetector;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;
import com.myappilication.xpress.finjan2017.models.login.login.loginreq;
import com.myappilication.xpress.finjan2017.models.login.login.loginresp;
import com.myappilication.xpress.finjan2017.webservice.RxClient;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainActivity extends AppCompatActivity {
    TextView tv_forgetpass;
    ImageView iv_logo;
    EditText etusername,etpassword;
    Button bt_login;
    Intent i;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String remember_token ="";
    NetConnectionDetector NDC;
    Context context;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        iv_logo = (ImageView) findViewById(R.id.imageView);
        etusername = (EditText) findViewById(R.id.et_username_login);
        etpassword = (EditText) findViewById(R.id.et_pass_login);
        tv_forgetpass = (TextView) findViewById(R.id.tv_forget_pass);
        bt_login = (Button) findViewById(R.id.bt_login);
        context = getApplicationContext();
        NDC = new NetConnectionDetector();
        etusername.setText("sugandhi.n@quadrupleindia.com");
        etpassword.setText("123456");

        tv_forgetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = new Intent(MainActivity.this,ForgotPasswordActivity.class);
                startActivity(i);
            }
        });
       /* if (NDC.isConnected(context)) {
            getlogindata();
        } else {
            Toast.makeText(MainActivity.this, "Check Your Internet Connnection", Toast.LENGTH_SHORT).show();

        }*/


        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.commit();




        Boolean NewUser = sharedpreferences.getBoolean(SharedPrefUtils.SpIsNewUser, true);

        if (!NewUser){
            Intent imodule = new Intent(MainActivity.this,ModuleFinJan.class);
            startActivity(imodule);
                   }

        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            getlogindata();

            }
        });

    }


    public void  getlogindata(){
        RxClient.get(MainActivity.this).Login(new loginreq(etusername.getText().toString(),
                etpassword.getText().toString()), new Callback<loginresp>() {
            @Override
            public void success(loginresp loginresp, Response response) {

                //Toast.makeText(getApplicationContext(),"sucesss",Toast.LENGTH_LONG).show();

                if (loginresp.getStatus().equals("200")){


                    editor.putBoolean(SharedPrefUtils.SpIsNewUser, false);
                    editor.putString(SharedPrefUtils.SpPassword, etpassword.getText().toString());
                    editor.putString(SharedPrefUtils.SpEmail, etusername.getText().toString());
                    editor.putString(SharedPrefUtils.SpRememberToken,loginresp.getToken().toString());

                  //  Toast.makeText(getApplicationContext(),"sucesss"+loginresp.getToken().toString(),Toast.LENGTH_LONG).show();
                    editor.commit();

                    i = new Intent(MainActivity.this,ProfileSetting.class);
                    startActivity(i);


                }
                else {


                    Toast.makeText(MainActivity.this, "Try again " + loginresp.getStatus(), Toast.LENGTH_LONG).show();
                }







            }

            @Override
            public void failure(RetrofitError error) {

                if (NDC.isConnected(context)) {
                    Toast.makeText(context, "Wrong Email Id And Password", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Check Your Internet Connnection", Toast.LENGTH_LONG).show();

                }

            }
        });

    }



}
