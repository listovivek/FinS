package com.myappilication.xpress.finjan2017.models.login.profileedit;

/**
 * Created by sureshmano on 3/13/2017.
 */

public class profilereq {

    String email;

    public profilereq( String email){

        this.email = email;

    }


}
