package com.myappilication.xpress.finjan2017.models.login.dashboard;

/**
 * Created by balasri on 14/3/17.
 */

public class DashboradReq {
        String email;

        public DashboradReq(String email){
            this.email = email;
        }


}