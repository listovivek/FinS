package com.myappilication.xpress.finjan2017.models.login.searchfaq;

/**
 * Created by sureshmano on 3/23/2017.
 */

public class searchinfo {


    private String updated_at;

    private String faq_ans;

    private String faq_qus;

    private String created_at;

    private String faq_modular;
    private String faq_id;

    public String getFaq_id ()
    {
        return faq_id;
    }

    public void setFaq_id (String faq_id)
    {
        this.faq_id = faq_id;
    }

    public String getUpdated_at ()
    {
        return updated_at;
    }

    public void setUpdated_at (String updated_at)
    {
        this.updated_at = updated_at;
    }

    public String getFaq_ans ()
    {
        return faq_ans;
    }

    public void setFaq_ans (String faq_ans)
    {
        this.faq_ans = faq_ans;
    }

    public String getFaq_qus ()
    {
        return faq_qus;
    }

    public void setFaq_qus (String faq_qus)
    {
        this.faq_qus = faq_qus;
    }

    public String getCreated_at ()
    {
        return created_at;
    }

    public void setCreated_at (String created_at)
    {
        this.created_at = created_at;
    }

    public String getFaq_modular ()
    {
        return faq_modular;
    }

    public void setFaq_modular (String faq_modular)
    {
        this.faq_modular = faq_modular;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [faq_id = "+faq_id+", updated_at = "+updated_at+", faq_ans = "+faq_ans+", faq_qus = "+faq_qus+", created_at = "+created_at+", faq_modular = "+faq_modular+"]";
    }
}
