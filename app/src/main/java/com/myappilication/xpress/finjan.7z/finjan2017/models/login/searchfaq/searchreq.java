package com.myappilication.xpress.finjan2017.models.login.searchfaq;

/**
 * Created by sureshmano on 3/23/2017.
 */

public class searchreq {

    String faq_modular;
    String search;

    public searchreq(String faq_modular,String search){
        this.faq_modular = faq_modular;
        this.search = search;
    }
}
