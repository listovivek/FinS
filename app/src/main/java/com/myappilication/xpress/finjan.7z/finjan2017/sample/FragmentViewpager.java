package com.myappilication.xpress.finjan2017.sample;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created by suresh on 20/4/17.
 */
public class FragmentViewpager extends FragmentPagerAdapter {

    private List<Fragment> mfFragments;


    public FragmentViewpager(FragmentManager fm, List<Fragment> frag_list) {
        super(fm);
        this.mfFragments = frag_list;
    }

    @Override
    public Fragment getItem(int position) {
        return mfFragments.get(position);
    }

    @Override
    public int getCount() {
        return mfFragments.size();
    }
}
