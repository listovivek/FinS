package com.myappilication.xpress.finjan2017.models.login.download;

/**
 * Created by balasri on 20/3/17.
 */

public class DownloadReq {
    String module_id;

    public DownloadReq(String module_id){
        this.module_id = module_id;
    }
}
