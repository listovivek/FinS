package com.myappilication.xpress.finjan2017.models.login.login;

/**
 * Created by sureshmano on 3/7/2017.
 */

public class loginreq {

    String email;
    String password;

    public loginreq(String email,String password ){

        this.email = email;
        this.password = password;

    }


}
