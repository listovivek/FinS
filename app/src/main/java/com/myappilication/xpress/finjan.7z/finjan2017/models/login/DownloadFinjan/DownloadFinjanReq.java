package com.myappilication.xpress.finjan2017.models.login.DownloadFinjan;

/**
 * Created by balasri on 20/4/17.
 */
public class DownloadFinjanReq {
    String module_id;

    public DownloadFinjanReq(String module_id){
        this.module_id = module_id;
    }
}