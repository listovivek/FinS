package com.myappilication.xpress.finjan2017;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.text.DecimalFormat;

public class CalcSip extends AppCompatActivity {

    EditText et_calcloan,et_calcinterest,et_calcterm,et_calcinvest,et_calcmaturity;
    Button btn_calculate;
    Toolbar toolbar;
    ImageButton imageButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calc_sip);
        et_calcloan = (EditText) findViewById(R.id.calc_loan);

        et_calcterm = (EditText) findViewById(R.id.calc_term);
        et_calcinterest = (EditText) findViewById(R.id.calc_interest);
        et_calcinvest = (EditText) findViewById(R.id.calc_total);
        et_calcmaturity = (EditText) findViewById(R.id.calc_maturity);
        btn_calculate = (Button) findViewById(R.id.calc_calculate);

        et_calcinvest.setEnabled(false);
        et_calcmaturity.setEnabled(false);


        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        imageButton = (ImageButton) findViewById(R.id.tb_normal_back);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });






        btn_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mtd_sip_calculation();


            }
        });













    }

    private void mtd_sip_calculation() {

        if (et_calcloan.length() == 0) {

            et_calcloan.setError("Enter Loan Amount");
            /*Toast.makeText(this, "", Toast.LENGTH_SHORT).show();*/

        }  else if (et_calcterm.length() == 0) {

            et_calcterm.setError("Enter Term");
            /*Toast.makeText(this, "", Toast.LENGTH_SHORT).show();*/

        }else if (et_calcinterest.length() == 0) {

            et_calcinterest.setError("Enter Interest");
            /*Toast.makeText(this, "", Toast.LENGTH_SHORT).show();*/

        }

        else {

            Double amount = Double.parseDouble(et_calcloan.getText().toString());
            Double Interest = Double.parseDouble(et_calcinterest.getText().toString());
            Double years = Double.parseDouble(et_calcterm.getText().toString());


            Double yearcount = (years * 12);
            Double inv = (amount) * yearcount;

            Double r = (Interest / 1200);
            Double temp = Math.pow((r + 1), yearcount);
            Integer pv = 0;
            Integer type = 1;

            Double fv = (-amount * (1 + r * type) * (1 - temp) / r) - pv * temp;
                /*double si = (amount * Interest * yearcount) / 100;*/
            et_calcinvest.setText(new DecimalFormat("##.##").format(inv));
            et_calcmaturity.setText(new DecimalFormat("##.##").format(fv));
        }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();

            case R.id.profile_menu:
                startActivity(new Intent(getApplicationContext(), ProfileSetting.class));
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;
            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;
            case R.id.calculator:
                startActivity(new Intent(getApplicationContext(), FinjanCalcModule.class));
                return true;
           /* case R.id.dashboard_menu:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;*/
      /*      case R.id.finjan_video:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/

        }
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }


}
