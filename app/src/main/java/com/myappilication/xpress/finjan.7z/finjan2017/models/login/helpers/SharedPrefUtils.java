package com.myappilication.xpress.finjan2017.models.login.helpers;

/**
 * Created by sureshmano on 3/8/2017.
 */

public class SharedPrefUtils {
    public static final String MyPREFERENCES = "finajanlogin";
    public static final String SpEmail = "SpEmail";
    public static final String SpIsNewUser = "SpIsNewUser";
    public static final String Speditprofilesuccess = "Speditprofilesuccess";
    public static final String Splastname = "Splastname";
    public static final String SpFirstname = "SpFirstname";
    public static final String SpPassword = "SpPassword";
    public static final String SpId = "SpId";
    public static final String SpUpdated = "SpUpdated";
    public static final String SpCompanyName = "SpCompanyName";
    public static final String SpUserName = "SpUserName";
    public static final String SpCreated = "SpCreated";
    public static final String SpUserId = "SpUserId";
    public static final String SpModules = "SpModules";
    public static final String SpExpDate = "SpExpDate";
    public static final String SpRememberToken = "SpRememberToken";
   // public static final String SpStatus = "SpStatus";
    public static final String user_ans = "user_ans";
    public static final String score = "score";
    public static final String SpStatus = "SpStatus";
    public static final String SpMcq_id = "SpMcq_id";
    public static final String SpModuleId = "SpModuleId";









}
