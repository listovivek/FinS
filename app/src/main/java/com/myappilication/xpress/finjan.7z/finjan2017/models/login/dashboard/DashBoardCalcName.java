package com.myappilication.xpress.finjan2017.models.login.dashboard;

/**
 * Created by balasri on 8/5/17.
 */
public class DashBoardCalcName {

        private String course_calculator;

        public String getCourse_calculator ()
        {
            return course_calculator;
        }

        public void setCourse_calculator (String course_calculator)
        {
            this.course_calculator = course_calculator;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [course_calculator = "+course_calculator+"]";
        }
    }


