package com.myappilication.xpress.finjan2017.models.login.helpers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboardCourses;

import java.util.ArrayList;
import java.util.List;

//import com.myappilication.xpress.finjan2017.model.login.dashboard.DashboardCourses;

/**
 * Created by balasri on 6/4/17.
 */
public class DataBase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "triviaQuiz";
    private SQLiteDatabase dbase;



    String module_id="MODULE_ID";
    String module_name="MODULE_NAME";
    String video_nam="VIDEO_NAME";
    String video_title="VIDEO_TITLE";
    String video_encrypt="VIDEO_ENCRYPT";
    String video_encrypt_type="VIDEO_ENCRYPT_TYPE";
    String video_language="VIDEO_LANGUAGE";
    String Filename="Filename";
    String Image="Image";



    private static final String TABLE_DOWNLOAD = "download";

    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase database) {
        String video = "CREATE TABLE IF NOT EXISTS " + TABLE_DOWNLOAD + " ( "
                + module_id + " INTEGER , " + module_name
                + " TEXT, " + video_nam+ " TEXT, "+video_title +" TEXT, " +video_encrypt +" TEXT, "+video_encrypt_type+" TEXT, "+video_language+" TEXT, "+Filename+" TEXT, "+Image+" TEXT)";
        database.execSQL(video);
//db.close();
    }
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
// Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOWNLOAD);
// Create tables again
        onCreate(db);
    }

    public void onDelete()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        //Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOWNLOAD);
// Create tables again
        onCreate(db);
    }
    // Adding new question

    public void data(List<DashboardCourses> quelist) {

        dbase=this.getWritableDatabase();
        for (DashboardCourses dc:quelist){
            ContentValues values = new ContentValues();
            values.put(module_id, dc.getId());
            values.put(module_name, dc.getModule_name());
            values.put(video_nam, dc.getVideo_name());
            values.put(video_title, dc.getVideo_title());
            values.put(video_encrypt, dc.getVideo_encrypt());
            values.put(video_encrypt_type, dc.getVideo_encrypt_type());
            values.put(video_language, dc.getVideo_language());
            String s = dc.getVideo_encrypt();
            int cs = s.indexOf("/");
            String finalFilname = s.substring(cs, s.length()) + "";
            values.put(Filename, finalFilname);
            values.put(Image, dc.getVideo_image());

            dbase.insert(TABLE_DOWNLOAD, null, values);
            Log.d("Dbase", String.valueOf(dbase));
        }


    }

    public List<DashboardCourses> getdata() {
        List<DashboardCourses> quesList = new ArrayList<>();
        // Select All Query
        String selectQuery ="SELECT  * FROM " + TABLE_DOWNLOAD ;
        int i =0;
        dbase=this.getReadableDatabase();
        Cursor cursor = dbase.rawQuery(selectQuery, new String[]{});
        //KEY_ID,KEY_QUES,KEY_ANSWER,KEY_OPTA,KEY_OPTB,KEY_OPTC,KEY_OPTD
        DashboardCourses list;
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                list  = new DashboardCourses();
                //String name = cursor.getString(7).toString();
                list.setId(cursor.getString(0));
                list.setModule_name(cursor.getString(1));
                list.setVideo_name(cursor.getString(2));
                list.setVideo_title(cursor.getString(3));
                list.setVideo_encrypt(cursor.getString(4));
                list.setVideo_encrypt_type(cursor.getString(5));
                list.setVideo_language(cursor.getString(6));
                list.setFile_Name(cursor.getString(7));
                list.setVideo_image(cursor.getString(8));

                quesList.add(list);
            } while (cursor.moveToNext());
        }

        dbase.close();
        return quesList;

    }





    }

