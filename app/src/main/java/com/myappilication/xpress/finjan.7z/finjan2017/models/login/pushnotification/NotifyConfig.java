package com.myappilication.xpress.finjan2017.models.login.pushnotification;

/**
 * Created by sureshmano on 3/13/2017.
 */

public class NotifyConfig {

    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";
}
