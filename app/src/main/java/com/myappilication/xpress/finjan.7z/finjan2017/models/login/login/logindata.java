package com.myappilication.xpress.finjan2017.models.login.login;

/**
 * Created by sureshmano on 3/7/2017.
 */

public class logindata {

    private String id;

    private String email;

    private String name;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", email = "+email+", name = "+name+"]";
    }
}
