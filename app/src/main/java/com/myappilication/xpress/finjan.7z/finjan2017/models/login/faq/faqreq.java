package com.myappilication.xpress.finjan2017.models.login.faq;

/**
 * Created by sureshmano on 3/16/2017.
 */

public class faqreq {

    String email;
    String module_id;


    public faqreq(String email,String module_id){

        this.email = email;
        this.module_id = module_id;
    }
}
