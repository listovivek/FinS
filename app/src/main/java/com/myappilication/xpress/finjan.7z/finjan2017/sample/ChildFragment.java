package com.myappilication.xpress.finjan2017.sample;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.myappilication.xpress.finjan2017.McqTestMainActivity;
import com.myappilication.xpress.finjan2017.R;
import com.myappilication.xpress.finjan2017.mcqevalutiontest.McQData;

import java.util.ArrayList;

/**
 * Created by suresh on 20/4/17.
 */
public class ChildFragment extends Fragment{

    public static final String QUESTION = "QUESTION";
    public static final String ANS1 = "ANSWER1";
    public static final String ANS2 = "ANSWER2";
    public static final String ANS3 = "ANSWER3";
    public static final String ANS4 = "ANSWER4";

    public static int count=0;
    public static String rItem;
    public static String radio1;
    public static String radio2;
    public static String radio3;
    public static String radio4;
    RadioGroup rg;

    private static ChildFragment childF;
    public static boolean condition = false;

    public RadioButton mcqRadiobutton1, mcqRadiobutton2, mcqRadiobutton3, mcqRadiobutton4;
    TextView questionSize, increase_Count, messageTextView;

    public static ViewGroup gp;



    public static ChildFragment getInstance() {

        if(childF == null){
            childF = new ChildFragment();
        }

        return childF;
    }

    public static void getIn() {
        ChildFragment f = new ChildFragment();

    }



    public static Fragment newInstance(String question, String ans1,
                                       String ans2, String ans3, String ans4) {

        ChildFragment f = new ChildFragment();


        Bundle bdl = new Bundle(1);
        bdl.putString(QUESTION, question);
        bdl.putString(ANS1, ans1);
        bdl.putString(ANS2, ans2);
        bdl.putString(ANS3, ans3);
        bdl.putString(ANS4, ans4);
       // bdl.putString(ANS1, ans1);
        f.setArguments(bdl);


        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        gp = container;
        String message = getArguments().getString(QUESTION);

        String ans1 = getArguments().getString(ANS1);
        String ans2 = getArguments().getString(ANS2);
        String ans3 = getArguments().getString(ANS3);
        String ans4 = getArguments().getString(ANS4);

        View v = inflater.inflate(R.layout.child_fragment, container, false);


         messageTextView = (TextView)v.findViewById(R.id.child_frag);


        messageTextView.setText(message);

        messageTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = messageTextView.getText().toString();
                Log.d("name", name);
            }
        });

        rg = (RadioGroup) v.findViewById(R.id.radioGroup1);

        mcqRadiobutton1 = (RadioButton) v.findViewById(R.id.ra);
        mcqRadiobutton2 = (RadioButton) v.findViewById(R.id.r1);
        mcqRadiobutton3 = (RadioButton) v.findViewById(R.id.r2);
        mcqRadiobutton4 = (RadioButton) v.findViewById(R.id.r3);






        mcqRadiobutton1.setText(ans1);

        mcqRadiobutton2.setText(ans2);
        mcqRadiobutton3.setText(ans3);
        mcqRadiobutton4.setText(ans4);
       // rItem=null;

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.ra:
                       rItem = mcqRadiobutton1.getText().toString();
                        Log.d("name", rItem);
                        condition = true;

                        break;
                    case R.id.r1:
                        rItem = mcqRadiobutton2.getText().toString();
                        Log.d("name", rItem);
                        condition = true;
                        break;
                    case R.id.r2:
                        rItem = mcqRadiobutton3.getText().toString();
                        Log.d("name", rItem);
                        condition = true;
                        break;
                    case R.id.r3:
                        rItem = mcqRadiobutton4.getText().toString();
                        Log.d("name", rItem);
                        condition = true;
                        break;
                }
            }
        });
        return v;

    }

   /* @Override
    public void onResume(){
        super.onResume();
        //rg.clearCheck();
        Log.d("clear", "radio");
    }*/



}
