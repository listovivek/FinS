package com.myappilication.xpress.finjan2017;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboardCourses;
import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboardResponse;
import com.myappilication.xpress.finjan2017.models.login.dashboard.DashboradReq;
import com.myappilication.xpress.finjan2017.models.login.faq.Faqlistdatas;
import com.myappilication.xpress.finjan2017.models.login.helpers.DataBase;
import com.myappilication.xpress.finjan2017.models.login.helpers.NetConnectionDetector;
import com.myappilication.xpress.finjan2017.models.login.helpers.SharedPrefUtils;
import com.myappilication.xpress.finjan2017.models.login.helpers.StaticConfig;
import com.myappilication.xpress.finjan2017.webservice.RxClient;

import java.util.ArrayList;
import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by Bala on 3/2/2017.
 */
public class ModuleFinJan extends AppCompatActivity {

    private RecyclerView recyclerView;
    String remember_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjMsImlzcyI6Imh0dHA6XC9cLzE4My44Mi4zMy4yMzI6ODA5NFwvYXBpXC9sb2dpbiIsImlhdCI6MTQ5MDY5NzcwMiwiZXhwIjoxNDkwNzAxMzAyLCJuYmYiOjE0OTA2OTc3MDIsImp0aSI6Ijg3NTIzNGQxOTlmMjkyY2E1NjMzNzY2YjZjZDU2ZWFkIn0.RtR5jF_vhPynlnvwC_odi5klUfcsCqY_Eg_zF-cmSlU";
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    TextView Tamil;
    TextView kannda;
    TextView hindi;
    TextView modularTamil;
    TextView modularHindi;
    TextView modularKannada;
    Intent k;
    ListView listView;
    List<DashboardCourses> queslist = new ArrayList<>();
    int score = 0;
    int qid = 0;
    DashboardCourses currentQ;
    //DbHelper db = new DbHelper(this);

    Context context;
    ArrayList<String> video_name = new ArrayList<>();
    ArrayList<String> Module_id = new ArrayList<>();
    ArrayList<String> Module = new ArrayList<>();
    ArrayList<String> enc_url = new ArrayList<>();
    ArrayList<String> Lang_id = new ArrayList<>();
    ArrayList<String> Res = new ArrayList<>();
    ArrayList<String> video_type = new ArrayList<>();
    ArrayList<String> video_image = new ArrayList<>();
    ArrayList<String> Calc = new ArrayList<>();


    private CalcAdapter calcadapter;
    calclistdatas listDatas;
    List<calclistdatas> list = new ArrayList<>();

    String img;

    String result;
    DataBase database;
    String str = "";

    ArrayAdapter<String> adapter;

    NetConnectionDetector NDC;


    Toolbar toolbar;
    ImageButton imageButton;




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.finjan_module);


   /*     recyclerView = (RecyclerView) findViewById(R.id.);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);*/



        sharedpreferences = getSharedPreferences(SharedPrefUtils.MyPREFERENCES, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();

        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        imageButton = (ImageButton) findViewById(R.id.tb_normal_back);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true);
                ModuleFinJan.this.finish();
            }
        });

        listView = (ListView) findViewById(R.id.list);
        database = new DataBase(ModuleFinJan.this);

        context = getApplicationContext();
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
       //queslist = (ArrayList<DashboardCourses>) database.getdata();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


      /* adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, Module);*/


        if (NDC.isConnected(context)) {
            mtd_module_list();


        } else {

            queslist=database.getdata();


            for (DashboardCourses dc:queslist) {

                Module.add(dc.getVideo_title());
                Module_id.add(dc.getId());
                video_name.add(dc.getVideo_name());
                enc_url.add(dc.getVideo_encrypt());
                Lang_id.add(dc.getVideo_language());
                Res.add(dc.getFile_Name());
                video_type.add(dc.getVideo_encrypt_type());
                video_image.add(dc.getVideo_image());
              //  Toast.makeText(ModuleFinJan.this, "cs" + Res, Toast.LENGTH_SHORT).show();
            }

            adapter = new ArrayAdapter(ModuleFinJan.this,
                    android.R.layout.simple_list_item_1, android.R.id.text1, Module);
            listView.setAdapter(adapter);


        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    final int position, long id) {
             /*   for (int i = 0; i < get.size(); i++) {
                    String s = get.get(i).trim();
*/
                int itemPosition = position;

                StaticConfig.posOfcalc = position;
                // ListView Clicked item value
              //  String itemValue = (String) listView.getItemAtPosition(position);

                // Show Alert
                   /* Toast.makeText(getApplicationContext(),
                            "Position :" + itemPosition + "  ListItem : " + itemValue, Toast.LENGTH_LONG)
                            .show();*/

                String mID = Module_id.get(position);
                editor.putString("name", mID);
                editor.commit();
                String enc = enc_url.get(position);
                img = video_image.get(position);

                editor.putString(SharedPrefUtils.SpModuleId, mID);
                editor.commit();


                String lang = Lang_id.get(position);
                String filename = Res.get(position);
                String vtype=video_type.get(position);
                Log.d("mID", mID);
               // Toast.makeText(ModuleFinJan.this, "enc" + enc, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), DashBoard.class);
                intent.putExtra("Module_name", Module.get(position));
                editor.putString("Module_name", Module.get(position));

                intent.putExtra("video_name", video_name.get(position));
                editor.putString("video_name", video_name.get(position));

                intent.putExtra("Video_image", img);
                editor.putString("Video_image", video_image.get(position));

                intent.putExtra("Module_id", mID);
                intent.putExtra("Encrypt_video", enc);
                editor.putString("Encrypt_video", enc_url.get(position));

                intent.putExtra("Lang_id", lang);
                editor.putString("Lang_id", Lang_id.get(position));

                intent.putExtra("Filename", filename);
                editor.putString("Filename", Res.get(position));

                intent.putExtra("Video_type", vtype);
                editor.putString("Video_type", video_type.get(position));

                editor.putString("Calc", Calc.toString());

                intent.putExtra("cal",Calc.get(position));
                editor.commit();
                startActivity(intent);

                // ListView Clicked item index
            }


        });
    }


    private void mtd_module_list() {

        RxClient.get(getApplicationContext()).DashBoard(sharedpreferences.getString(SharedPrefUtils.SpRememberToken, ""), new DashboradReq(sharedpreferences.getString(SharedPrefUtils.SpEmail, "")),
                new Callback<DashboardResponse>() {
            @Override
            public void success(DashboardResponse dashboardResponse, Response response) {

                queslist = new ArrayList<DashboardCourses>();

                for (int i = 0; i < dashboardResponse.getResult().getInfo().getCourses().length; i++) {
                    //    Toast.makeText(ModuleFinJan.this, "gh" + Module_id.add(dashboardResponse.getResult().getInfo().getCourses()[i].getId()), Toast.LENGTH_SHORT).show();

                    database.onDelete();
                    queslist.add(dashboardResponse.getResult().getInfo().getCourses()[i]);


                    database.data(queslist);







                    Log.d("Ques", String.valueOf(queslist));

                    queslist = (ArrayList<DashboardCourses>) database.getdata();
                    currentQ = queslist.get(qid);

                    // listView.add()
                    Module.add(dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_title());
                    video_name.add(StaticConfig.Base + dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_name());
                    Module_id.add(dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_language());
                    enc_url.add(StaticConfig.Base + dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_encrypt());
                    Lang_id.add(dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_language());
                    video_type.add(dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_encrypt_type());
                    video_image.add(StaticConfig.Base+dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_image());

                    for (int j = 0; j <dashboardResponse.getResult().getInfo().getCourses()[i].getCalculator_name().length ; j++) {
                        
                        Calc.add(dashboardResponse.getResult().getInfo().getCourses()[i].toString());

                    }


                    String s = dashboardResponse.getResult().getInfo().getCourses()[i].getVideo_encrypt();

                    int cs = s.indexOf("/");
                    result = s.substring(cs, s.length()) + "";
                  //  Toast.makeText(ModuleFinJan.this, "cs" + result, Toast.LENGTH_SHORT).show();
                    Log.d("Res........", result);
                    Res.add(result);
                    Log.d("Fileres", String.valueOf(Res));

                }



           /*     Log.d("module id", Module_id.toString());
                for (DashboardCourses dc:queslist) {

                    Module.add(dc.getVideo_title());
                    Module_id.add(dc.getId());
                    video_name.add(dc.getVideo_name());
                    enc_url.add(dc.getVideo_encrypt());
                    Lang_id.add(dc.getVideo_language());
                    //listView.performClick();
            *//*  s.add(dc.getId());

            s2.add(StaticConfig.Base + dc.getVideo_encrypt());*//*
                    //Lang_id.add(dc.getVideo_language());
                }
*/
                adapter = new ArrayAdapter(ModuleFinJan.this,
                        android.R.layout.simple_list_item_1, android.R.id.text1, Module);
                listView.setAdapter(adapter);

            }

            @Override
            public void failure(RetrofitError error) {

            }
        });
    }


    @Override
    public void onBackPressed() {

        this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.profile_menu:
                startActivity(new Intent(getApplicationContext(), ProfileSetting.class));
                return true;
            case R.id.finstaffcources:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;

            case R.id.faq:
                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
                return true;
            case R.id.calculator:
                startActivity(new Intent(getApplicationContext(), FinjanCalcModule.class));
                return true;
           /* case R.id.dashboard_menu:
                startActivity(new Intent(getApplicationContext(), ModuleFinJan.class));
                return true;*/
          /*  case R.id.finjan_video:
                startActivity(new Intent(getApplicationContext(), FinjanActivity.class));
                return true;*/



        }
        return false;
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_for_all, menu);

        return true;
    }

}





