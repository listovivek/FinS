package com.myappilication.xpress.finjan2017;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.myappilication.xpress.finjan2017.mcqevalutiontest.McQData;
import com.myappilication.xpress.finjan2017.models.login.evalution.EvalutionModularQues;
import com.myappilication.xpress.finjan2017.models.login.helpers.NetConnectionDetector;
import com.myappilication.xpress.finjan2017.sample.ChildFragment;
import com.myappilication.xpress.finjan2017.sample.FragmentViewpager;

import java.util.ArrayList;
import java.util.List;

import retrofit.RestAdapter;

/**
 * Created by suresh on 21/4/17.
 */
public class McqTestMainActivity extends FragmentActivity {

    ViewPager pager;
    ArrayList<String> ans_list = new ArrayList<>();
    ArrayList<String> tempcount_list = new ArrayList<>();
    int count =0;
    FragmentViewpager pageAdapter;
    int pagepostion=0;
    public static int scrore;
    static boolean preCon = false;
    boolean tempCondition = false;
    NetConnectionDetector NDC;
    Context context;

    ArrayList<String> db_qusList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.mcq_fragment_viewpager);

        context = getApplicationContext();
        NDC = new NetConnectionDetector();

       /* final List<Fragment> frag_list = getFragment(McQData.getInstance().getMCQQuestion());
        pageAdapter = new FragmentViewpager(getSupportFragmentManager(), frag_list);*/

        if(NDC.isConnected(context)){
            final List<Fragment> frag_list = getFragment(McQData.getInstance().getMCQQuestion());
            pageAdapter = new FragmentViewpager(getSupportFragmentManager(), frag_list);

        }/*else{
           final List<Fragment> frag_list = getDBFragment(DashBoard.quesList);
            pageAdapter = new FragmentViewpager(getSupportFragmentManager(), frag_list);
        }*/

        pager = (ViewPager) findViewById(R.id.fragment_viewpager);
        tempcount_list.add("0");

        pager.beginFakeDrag();
        pager.setAdapter(pageAdapter);
       // ans_list.add(0);
        pagepostion = pager.getCurrentItem();

        Button nextButton = (Button) findViewById(R.id.next_button);
        final Button preButton = (Button) findViewById(R.id.pre_button);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pager.setCurrentItem(pager.getCurrentItem()+1, true);

                if(preCon == true && ChildFragment.condition == true){


                    for(int n=0; n<=tempcount_list.size();n++){
                        if(n==count){
                            ans_list.set(n, ChildFragment.rItem);
                            Log.d("replace list", ans_list.toString());
                            tempCondition=true;
                            break;
                        }else{
                            tempCondition=false;
                        }
                    }


                    /*if(ans_list.size()>count){
                        ans_list.set(count, ChildFragment.rItem);
                        Log.d("replace list", ans_list.toString());
                        tempCondition=true;
                    }else{
                        tempCondition=false;
                    }*/
                }


                Log.d("count", ""+count);
                count++;

                if(NDC.isConnected(context)){
                    if(McQData.getInstance().getMCQQuestion().size() == count){
                        Log.d("count", ""+count);
                    //    Toast.makeText(McqTestMainActivity.this, "finish", Toast.LENGTH_SHORT).show();

                        Log.d("final list", ans_list.toString());
                        McQData.getInstance().setUserSelectedData(ans_list);
                        finishDialog();

                    }else{
                        tempcount_list.add(String.valueOf(count));
                        Log.d("temp count", tempcount_list.toString());
                        Log.d("increase count", ""+count);
                    }
                }else{
                    if(db_qusList.size() == count){
                        Log.d("count", ""+count);
                    //    Toast.makeText(McqTestMainActivity.this, "finish", Toast.LENGTH_SHORT).show();

                        Log.d("final list", ans_list.toString());

                        //finishDialog();
                        McQData.getInstance().setUserSelectedData(ans_list);
                    }else{
                        tempcount_list.add(String.valueOf(count));
                        Log.d("temp count", tempcount_list.toString());
                        Log.d("increase count", ""+count);
                    }
                }


                if(ChildFragment.rItem != null && tempCondition == false && ChildFragment.condition == true){
                    ans_list.add(ChildFragment.rItem);
                }else{

                }
                ChildFragment.condition = false;
                preCon = false;
                tempCondition=false;

/*
                pagepostion = pager.getCurrentItem();
                Log.d("next page position", ""+pagepostion);
                //ans_list.add(pagepostion);


                if(pagepostion == McQData.getInstance().getMCQcorrectans().size()){
                    Log.d("next page position", ""+pagepostion);
                }else{
                    Log.d("next page position", ""+pagepostion);
                }
*/

               // Log.d("list", ""+ans_list);
                /*if(ans_list != null){

                    for(int i=0; i<ans_list.size(); i++){

                        if(i == ans_list.get(i)){

                        }else{

                        }
                    }
                }*/

              //  pagepostion++;
               /* if(pagepostion == McQData.getInstance().getMCQcorrectans().size()){
                    Log.d("next page position", ""+pagepostion);
                }else{
                    Log.d("next page position", ""+pagepostion);
                }



                Log.d("count", ""+count);

                *//*if(ChildFragment.rItem != null){
                    ans_list.add(ChildFragment.rItem);
                    Log.d("ans list", ans_list.toString());
                }*//*

                ChildFragment.rItem = null;
                pager.setCurrentItem(pager.getCurrentItem()+1, true);

                if(McQData.getInstance().getMCQQuestion().size() == count){

                }else{
                    count++;
                }*/


            }
        });

        preButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pager.setCurrentItem(pager.getCurrentItem()-1, true);

                preCon = true;

                Log.d("count", ""+count);

                tempcount_list.remove(count);
                Log.d("remove temp count", ""+tempcount_list);

                if(0 == count){
                    Log.d("count", ""+count);
                    count = 0;
                   // Toast.makeText(McqTestMainActivity.this, "finish", Toast.LENGTH_SHORT).show();
                }else{
                    count--;
                    Log.d("decrease count", ""+count);
                }
                ChildFragment.condition = false;

            }
        });
    }

    private void finishDialog() {

        for(int i=0; i<McQData.getInstance().getMCQcorrectans().size(); i++) {
            if(McQData.getInstance().getUserSelectedData().get(i).
                    equalsIgnoreCase(McQData.getInstance().getMCQcorrectans().get(i))){
                scrore = i;
                Log.d("correct answer", ""+ scrore);
            }else{
                int cA = i;
                Log.d("worng answer", ""+ cA);
            }
        }

        Intent intent = new Intent(McqTestMainActivity.this, ActivityEvaluation.class);
        startActivity(intent);


        /*final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.custom_alert_dialog);
        dialog.setCancelable(false);
        TextView t = (TextView) dialog.findViewById(R.id.dialog_text);
        Button okButton = (Button) dialog.findViewById(R.id.ok_btn);
        Button cancelButton = (Button) dialog.findViewById(R.id.cancel_btn);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            Log.d("final ans", ans_list.toString());

               *//* Intent intent = new Intent(McqTestMainActivity.this, ActivityEvaluation.class);
                startActivity(intent);

                for(int i=0; i<McQData.getInstance().getMCQcorrectans().size(); i++) {
                    if(McQData.getInstance().getUserSelectedData().get(i).
                            equalsIgnoreCase(McQData.getInstance().getMCQcorrectans().get(i))){
                        scrore = i;
                        Log.d("correct answer", ""+ scrore);
                    }else{
                        int cA = i;
                        Log.d("worng answer", ""+ cA);
                    }
                }*//*
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                dialog.cancel();
            }
        });
    dialog.show();*/

    }

    private List<Fragment> getDBFragment(List<EvalutionModularQues> quesList) {
        List<Fragment> f = new ArrayList<>();

        for(EvalutionModularQues dc : quesList){
            db_qusList.add(dc.getMcq_qus());
            f.add(ChildFragment.newInstance(dc.getMcq_qus(),
                    dc.getMcq_ans1(), dc.getMcq_ans2(),
                    dc.getMcq_ans3(), dc.getMcq_ans4()));
        }


        return f;
    }

    private List<Fragment> getFragment(ArrayList<String> mcqQuestion) {
        List<Fragment> f = new ArrayList<>();

        for(int t=0; t<mcqQuestion.size(); t++){
            f.add(ChildFragment.newInstance(McQData.getInstance().getMCQQuestion().get(t),
                    McQData.getInstance().getMCQanswer1().get(t), McQData.getInstance().getMCQanswer2().get(t),
                    McQData.getInstance().getMCQanswer3().get(t),McQData.getInstance().getMCQanswer4().get(t)));
        }




        return f;
    }


}
