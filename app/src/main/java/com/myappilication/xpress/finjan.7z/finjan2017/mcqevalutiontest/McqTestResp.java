package com.myappilication.xpress.finjan2017.mcqevalutiontest;

/**
 * Created by suresh on 24/4/17.
 */
public class McqTestResp {

    String status;
    String result;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }


}
