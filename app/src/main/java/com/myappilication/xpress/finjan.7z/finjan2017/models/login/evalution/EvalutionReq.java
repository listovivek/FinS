package com.myappilication.xpress.finjan2017.models.login.evalution;

/**
 * Created by balasri on 17/3/17.
 */

public class EvalutionReq {
            String email;

        public EvalutionReq(String email){
            this.email = email;
        }


    }

